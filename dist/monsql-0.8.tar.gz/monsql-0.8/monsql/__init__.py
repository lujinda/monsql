#!/usr/bin/env python
#coding:utf-8
# Author        : tuxpy
# Email         : q8886888@qq.com.com
# Last modified : 2015-11-15 22:43:39
# Filename      : __init__.py
# Description   : 
from __future__ import absolute_import
from monsql.monsql  import *

version = 0.8

